# micro:bit知识库
在这里，你能找到与micro:bit有关的所有信息。

![](https://i.imgur.com/pSWTsPv.jpg)

