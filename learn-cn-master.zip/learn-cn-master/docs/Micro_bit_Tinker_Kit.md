## Tinker Kit 介绍

ElecFreaks Micro:bit Tinker Kit是micro:bit的套件，无需复杂的面包板线，你就能连接各种模块，完成自己的创意。

## 文件
- [Octopus:bit 介绍](Octopus_bit_CN.md)
- [Case_01 音乐精灵](Micro_bit_Tinker_Kit_Case_01_Music_Machine_CN.md)
- [Case_02 智能光线](Micro_bit_Tinker_Kit_Case_02_Smart_Light_CN.md)
- [Case_03 电子琴](Micro_bit_Tinker_Kit_Case_03_Electro_Theremin_CN.md)
- [Case_04 简易报警器](Micro_bit_Tinker_Kit_Case_04_Simple_Alarm_Box_CN.md)
- [Case_05 植物土壤湿度检测装置](Micro_bit_Tinker_Kit_Case_05_Plant_Monitoring_Device_CN.md)
- [Case_06 入侵检测系统](Micro_bit_Tinker_Kit_Case_06_Intruder_Detection_CN.md)
- [Case_07 喂鱼器](Micro_bit_Tinker_Kit_Case_07_Fish_Feeder_CN.md)
- [Case_08 运动检测器](Micro_bit_Tinker_Kit_Case_08_Motion_Detector_CN.md)
- [Case_09 测谎仪](Micro_bit_Tinker_Kit_Case_09_Lie_Detector_CN.md)
- [Case_10 打乒乓球游戏](Micro_bit_Tinker_Kit_Case_10_PADDLEBALLSUPERSMASHEM_CN.md)
- [Case_11 规避小行星](Micro_bit_Tinker_Kit_Case_11_Avoid_Asteroids_CN.md)
- [Case_12 远程控制](Micro_bit_Tinker_Kit_Case_12_Remote_Control_Everything_CN.md)
- [Case_13 自驱车](Micro_bit_Tinker_Kit_Case_13_Micro_Bit_Car_CN.md)
- [Case_14 抛煎饼](Micro_bit_Tinker_Kit_Case_14_Flipping_Pancakes_CN.md)
- [Case_15 迷宫游戏](Micro_bit_Tinker_Kit_Case_15_Maze_Runner_CN.md)
- [Case_16 速算游戏](Micro_bit_Tinker_Kit_Case_16_QUICK_MATHS_CN.md)
- [Case_17 识别出正确音调](Micro_bit_Tinker_Kit_Case_17_Pitch_Perfect_CN.md)
- [Case_18 反应力测试](Micro_bit_Tinker_Kit_Case_18_Finger_Dexterity_CN.md)
- [Case_19 水平仪](Micro_bit_Tinker_Kit_Case_19_Electric_Spirit_Level_CN.md)
- [Case_20 太空大战游戏](Micro_bit_Tinker_Kit_Case_20_Space_Shooter_CN.md)
- [Case_21 飞行的小鸟](Micro_bit_Tinker_Kit_Case_21_Flappy_Bird_CN.md)
- [Case_22 有线传输](Micro_bit_Tinker_Kit_Case_22_Wire_Transmission_CN.md)
- [Case_23 贪吃蛇](Micro_bit_Tinker_Kit_Case_23_Snake_Game_CN.md)
- [Case_24 组装Game:bit!](Micro_bit_Tinker_Kit_Case_24_Game_Bit_CN.md)

