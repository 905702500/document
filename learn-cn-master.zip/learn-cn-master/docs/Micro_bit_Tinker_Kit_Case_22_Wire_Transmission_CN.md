一起来用摩尔斯代码，钓鱼线，一个舵机和一个传感器在两块micro:bit之间传递信息吧！有了这些已经足够了，为什么还要使用micro:bit无线电呢？


## 制作目标  
---

使用Python来给micro:bit编程。
使用摩尔斯代码表给摩尔斯代码加密或破解摩尔斯代码。
移动舵机以及使用碰撞传感器检测。


## 制作材料
---

- 2 x [BBC Micro:bit](http://www.elecfreaks.com/estore/micro-bit-board.html)
- 2 x [扩展板](http://www.elecfreaks.com/estore/elecfreaks-micro-bit-breakout-board.html)
- 2 x Micro-USB线
- 1 x 舵机
- 1 x [碰撞传感器](http://www.elecfreaks.com/estore/octopus-crash-sensor-brick.html)
- 细线 （例如：钓鱼线）
- 硬纸板（可有可无）

在这个Gif图片中你可能看不见这跟细线，但是它却是真实存在于舵机和碰撞传感器之间哦！

![](https://www.elecfreaks.com/wp-content/uploads/2018/02/1.gif)

**温馨提示: 如果你想要以上所有这些元器件，你可以购买我们的[micro:bit小小发明家套件](https://item.taobao.com/item.htm?spm=a230r.7195193.1997079397.9.z3IMPf&id=564707672256&abbucket=5)。**


## 为什么选择Python?  
---

读起来和英语一样 – Python是读起来最简单的一种编程语言。这使它成为了一门最适合编程初学者学习的语言。
灵活多变 – Python成为行业标准的编程语言是有原因的。它可以用来做很多事。这就是为什么谷歌和Youtube把它作为它们的后端软件的一部分。 社区活跃 - Python是初学者们最喜欢的一门语言。在Python社区里面，你可以找到数以万计的资源，寻求到很多帮助。这些帮助不仅仅局限于帮助你检查你的代码。这些资源和帮助是无价的，它可以帮助你扫除编程学习路途中的所有绊脚石。


## 如何用Python开始编程？  
---

你可以在micro:bit Python官方编辑器内编写你的Pyhton代码。 点击下载按钮，把.hex文件拖动到连接电脑的MICROBIT驱动中，程序就可以运行了。

## 概览  
---

我们将使用2块micro:bit：一块用于发送摩尔斯代码，另一块用于接收摩尔斯代码。数据的传输将会通过一段线来完成。当舵机拉扯线的时候（基于编码输入），碰撞传感器就会检测到线的拉动并且将摩尔斯代码转换成文字。当然，你可以通过micro:bit内置的无线电传输数据。但是，这样又有什么乐趣呢？

## 组装部件  
---

![](https://www.elecfreaks.com/wp-content/uploads/2018/02/2-3.jpg)

将舵机粘在硬纸板上。将细线的一端缠绕在舵机转轴的末尾，另一端缠绕在碰撞传感器的金属弹片上。把碰撞传感器放置得远一些，这样当舵机转动时，细线就会被拉动，传感器被激活。如果你没有一块硬纸板的话，你可以把这些东西粘在桌子上。在micro:bit发送端,将舵机连接扩展板上的P0.在micro：bit接收端，将碰撞传感器连接扩展板上的P0。


## 摩尔斯代码是什么？  
---

摩尔斯代码是一种通过长(“-“,或“dah”)和短 (“.”, 或 “dit”)的信号组合来传输文本的代码。每个字母以及从0到9的数字都有它们自己的摩尔斯代码的表示。文字通过停顿隔开。


### 发送步骤1：将文本转换成摩尔斯代码  

假设我们给出文本“HELLO WORLD”，并且想要把它转换成摩尔斯代码。首先，我们需要一个“表格”说明每个字母的摩尔斯代码是什么。因此，我们就能够（举个例子）知道“E”是“.”， “W”是“.-”。

我们可以使用一种Python的数据结构dictionary（字典）。这种结构可以是我们将关键字和数值联系起来。在本案例中，关键字应该是字母，数值应该是摩尔斯代码的相应符号。

![](https://www.elecfreaks.com/wp-content/uploads/2018/02/3-4.png)

这里有一个字典的示例：


MORSE_CODE = {'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.', 'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..', 'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.', 'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-', 'Y': '-.--', 'Z': '--..', '0': '-----', '1': '.----', '2': '..---', '3': '...--', '4': '....-', '5': '.....', '6': '-....', '7': '--...', '8': '---..', '9': '----.' }


现在我们可以将每个单独的字母转换成摩尔斯代码。我们需要把所有的信息组合起来，在每个字母的末尾添加一个空格，告诉接收端一个字母已经发送。


### 发送步骤2：用摩尔斯代码使舵机旋转  

当我们把信息转换成摩尔斯代码的格式后，接下来就是基于编写好的信息让舵机转动。在本案例中，dit将代表一个0.6s的拉力，dah表示一个1.2s的拉力，一个空格表示一个1.6s的拉力。

首先，我们需要找到舵机旋转的正确角度，制造出想要的效果：拉紧传感器一端的细线可以激活传感器，而松开细线则不激活传感器。我们将把这些数值命名为press_angle和release_angle。对于这种设置，它们的数值通常是150和60。但是，根据舵机和传感器位置的不同，它们的数值也会有所不同。

为了使舵机转动，我们将使用一个类。你可以在此获得这个类。要在在线编辑器中使用这个类，你需要将这段代码复制粘贴到程序的开端。

对于每个字符(dit, dah 或 空格)，我们应该设置一段合适的时间长度用于拉紧细线，然后短暂的松开细线一小会儿。 

![](https://www.elecfreaks.com/wp-content/uploads/2018/02/5-5.png)
![](https://www.elecfreaks.com/wp-content/uploads/2018/02/4-4.jpg)


### 接收步骤1：将传感器数据转换成摩尔斯代码  

当传感器一端的细线被拉紧，它将会按下传感器上的金属弹片，使用模拟输入就可以检测到弹片被按下。无论弹片什么时候被按下，模拟读数都会小于一个阈值。在本案例中，我们将使用一个100的阈值。

在弹片被按下的时候，我们可以使用事件接收器来引发事件，使轮询的执行更简单。这意味着按照一定的间隔查看模拟读数。在本案例中，间隔是0.1s。

如果在一个循环中，弹片被按下，我们将把press_length增加100来追踪到目前为止弹片被按下了多久。如果弹片发现被松开了，我们可以使用press_length来发现按钮被按下了多久，并由此来决定哪个字符（dit, dah或space）已经被传输了。我们将把这个添加到变量cur_letter，让其追踪到目前为止所发送的dits和dahs。

![](https://www.elecfreaks.com/wp-content/uploads/2018/02/6-2.jpg)
![](https://www.elecfreaks.com/wp-content/uploads/2018/02/7-3.png)


### 接收步骤2：将摩尔斯代码转换为文字  

每当检测到一个空格被检测，它就会选取目前已经被检测到的字符(dits 或 dahs)，并将其转换为一个字母。我们将需要再次使用dictionary（字典）。这一次，关键字将会是摩尔斯代码表示，数值将会是字母。

这里有一个解码字典的示例：


MORSE_DECODE = {'.-': 'A', '-...': 'B', '-.-.': 'C', '-..': 'D', '.': 'E', '..-.': 'F', '--.': 'G', '....': 'H', '..': 'I', '.---': 'J', '-.-': 'K', '.-..': 'L', '--': 'M', '-.': 'N', '---': 'O', '.--.': 'P', '--.-': 'Q', '.-.': 'R', '...': 'S', '-': 'T', '..-': 'U', '...-': 'V', '.--': 'W', '-..-': 'X', '-.--': 'Y', '--..': 'Z', '-----': '0', '.----': '1', '..---': '2', '...--': '3', '....-': '4', '.....': '5', '-....': '6', '--...': '7', '---..': '8', '----.': '9'}

![](https://www.elecfreaks.com/wp-content/uploads/2018/02/8-3.png)

现在，无论一个字母什么时候被检测到（或者是一个空格被按下），我们可以在解码字典里面查询相应的字母。但是，有时候接收器可能不能准确检测到线被拉扯的序列，因此在字典里面就找不到该序列。如果我们试着在字典里面查找序列但是找不到，Python将会显示出错，程序就会停止运行。

因此，我们首先要检查这个序列是否在字典的关键字中。如果不在，我们将把当前的字符设置为“？”。一旦我们有了当前的字符，我们就能够通过设置变量cur_char，在micro:bit的LED屏幕上显示出这个字符。在每个循环中，我们将显示检测到的字符。


### 将发送和接收结合起来  

如果初次使用的时候这个装置不能完美地工作，那也没关系！试着调整一下舵机或传感器的位置，以及调整舵机拉紧或松开细线的角度。此外，你可以试着调整一下拉线的持续时间。这里是[发送](https://pastebin.com/Qm7ZjxHJ)和[接收](https://pastebin.com/JLEkPyYS)的完整代码。 


## 更多扩展
---

虽然这种数据传输的方法并不是用于特殊用途，但是许多数据转换的概念是相关连的。试着用线的长度来做实验，看看多远的距离可以被平稳传送，以及在哪个点“信号”变得很弱，难以被检测到。

为了增强“信号”，你可以使用第三块micro:bit来作为信号放大器。它可以把传感器的信号转换为新的拉力，这和每20千米安装在水下的光纤电缆的信号增强器的原理是类似的。

当然，摩尔斯代码不是最有效最可靠的数据传输方式。 用不同类型的编码(二进制代码 + ASCII，海明码，等等), 以及探索一些错误修正代码，来检测和修复传输过程中的任何数据损失或错误。 

![](https://www.elecfreaks.com/wp-content/uploads/2018/02/9-2.png)


## 常见问题
---


## 相关阅读  
---

[Micro:bit小小发明家课程01:音乐播放器](/Micro_bit_Tinker_Kit_Case_01_Music_Machine_CN/)                        
[Micro:bit小小发明家课程02:智能灯](/Micro_bit_Tinker_Kit_Case_02_Smart_Light_CN/)  
[Micro:bit小小发明家课程03:电子琴](/Micro_bit_Tinker_Kit_Case_03_Electro_Theremin_CN/)   
[Micro:bit小小发明家课程04:报警装置](/Micro_bit_Tinker_Kit_Case_04_Simple_Alarm_Box_CN/)   
[Micro:bit小小发明家课程05:土壤湿度检测](/Micro_bit_Tinker_Kit_Case_05_Plant_Monitoring_Device_CN/)   
[Micro:bit小小发明家课程06:入侵检测](/Micro_bit_Tinker_Kit_Case_06_Intruder_Detection_CN/)   
[Micro:bit小小发明家课程07:喂鱼器](/Micro_bit_Tinker_Kit_Case_07_Fish_Feeder_CN/)  
[Micro:bit小小发明家课程08:运动检测](/Micro_bit_Tinker_Kit_Case_08_Motion_Detector_CN/)   
[Micro:bit小小发明家课程09:测谎仪](/Micro_bit_Tinker_Kit_Case_09_Lie_Detector_CN/)   
[Micro:bit小小发明家课程10:乒乓球游戏](/Micro_bit_Tinker_Kit_Case_10_PADDLEBALLSUPERSMASHEM_CN/)   
[Micro:bit小小发明家课程11:躲避小行星](/Micro_bit_Tinker_Kit_Case_11_Avoid_Asteroids_CN/)   
[Micro:bit小小发明家课程12:遥控小车](/Micro_bit_Tinker_Kit_Case_12_Remote_Control_Everything_CN/)  
[Micro:bit小小发明家课程13:micro:bit小车](/Micro_bit_Tinker_Kit_Case_13_Micro_Bit_Car_CN/)  
[Micro:bit小小发明家课程14:抛煎饼游戏](/Micro_bit_Tinker_Kit_Case_14_Flipping_Pancakes_CN/)  
[Micro:bit小小发明家课程15:跑迷宫游戏](/Micro_bit_Tinker_Kit_Case_15_Maze_Runner_CN/)  
[Micro:bit小小发明家课程16:速算游戏](/Micro_bit_Tinker_Kit_Case_16_QUICK_MATHS_CN/)  
[Micro:bit小小发明家课程17:猜音调游戏](/Micro_bit_Tinker_Kit_Case_17_Pitch_Perfect_CN/)  
[Micro:bit小小发明家课程18:手指灵敏度游戏](/Micro_bit_Tinker_Kit_Case_18_Finger_Dexterity_CN/)  
[Micro:bit小小发明家课程19:电子水平仪](/Micro_bit_Tinker_Kit_Case_19_Electric_Spirit_Level_CN/)  
[Micro:bit小小发明家课程20:太空射击游戏](/Micro_bit_Tinker_Kit_Case_20_Space_Shooter_CN/)   
[Micro:bit小小发明家课程21:飞行的小鸟游戏](/Micro_bit_Tinker_Kit_Case_21_Flappy_Bird_CN/)   
[Micro:bit小小发明家课程23:贪吃蛇游戏](/Micro_bit_Tinker_Kit_Case_23_Snake_Game_CN/)  



