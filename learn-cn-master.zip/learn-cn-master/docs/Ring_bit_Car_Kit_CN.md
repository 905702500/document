## Ring:bit小车套件简介

Ring:bit小车是一种基于BBC micro:bit和ELECFREAKS ring"bit的DIY智能汽车。ring:Bit扩展了三路GPIO，其中两路用于驱动伺服电机，一路GPIO未定义，可以用于其他功能。


## 相关文档
- [Ring:bit 简介](/Ring_bit_CN/)
- [Case_01 添加代码库](/Ring_bit_Car_Kit_Case_01_Add_Package_CN/)
- [Case_02 折线行走](/Ring_bit_Car_Kit_Case_02_S_Walk_CN/)
- [Case_03 画圆](/Ring_bit_Car_Kit_Case_03_Draw_a_Circel_CN/)
- [Case_04 无线遥控小车](/Ring_bit_Car_Kit_Case_04_Wireless_Remote_Control_CN/)
