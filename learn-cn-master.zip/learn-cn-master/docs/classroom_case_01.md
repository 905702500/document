## 闪烁的心

### 步骤 1

将`显示LED`积木块放在`开机时执行`积木块内并画出一颗心。

![](https://i.imgur.com/JHEDgQp.png)

### 步骤 2

点击`下载`，将你的代码下载到micro:bit上吧！

### 步骤 3

将另一个`显示LED`放在心得下方以使之闪烁。

![](https://i.imgur.com/ddfDrOZ.png)

### 步骤 4

将这些积木块放在`无限循环`积木块内部使动画重复运行。

![](https://i.imgur.com/Y9otRbu.png)

### 步骤 5

点击`下载`，将你的代码下载到micro:bit，然后观察心的闪烁吧！

### 步骤 6

将更多的`显示LED`积木块放入其中来创作你自己的动画。

![](https://i.imgur.com/kn6t2rx.png)

### 步骤 7

点击`下载`，将你的代码下载到micro:bit上吧！

<div style="position:relative;height:0;padding-bottom:70%;overflow:hidden;"><iframe style="position:absolute;top:0;left:0;width:100%;height:100%;" src="https://makecode.microbit.org/#pub:_ARKfyUVW5F7e" frameborder="0" sandbox="allow-popups allow-forms allow-scripts allow-same-origin"></iframe></div>
