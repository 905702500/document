## 翻转硬币

### 步骤 1

当按钮A被按下，添加一个`当按钮被按下`积木块来运行代码。

![](https://i.imgur.com/b1IU5H7.png)

### 步骤 2

添加一个**如果**积木块来检查从`随机选取true或false`积木块返回的数值。
`随机选取true或false`随机返回到`true`或者`false`。

![](https://i.imgur.com/tOTSWPh.png)

### 步骤 3

在**如果**积木块下方放入一个`显示图标`积木块，并选择其中一个图像。

![](https://i.imgur.com/LZSiCqL.png)

### 步骤 4

点击`下载`，将代码下载到micro:bit上，并试着按下按钮A。

### 步骤 5

在**如果**前面放入多个`显示图标`积木块来创造一枚硬币翻转的动画。

![](https://i.imgur.com/Z4w3fna.png)

### 步骤 6

点击`下载`，将代码下载到micro:bit上，并按下按钮A试试看吧！

<div style="position:relative;height:0;padding-bottom:70%;overflow:hidden;"><iframe style="position:absolute;top:0;left:0;width:100%;height:100%;" src="https://makecode.microbit.org/#pub:_ApT1b1LU1Mq9" frameborder="0" sandbox="allow-popups allow-forms allow-scripts allow-same-origin"></iframe></div>
