# 欢迎来到micro:bit知识库

![](https://i.imgur.com/LTOqQvh.jpg)

## English WIKI
[English WIKI](https://www.elecfreaks.com/learn-en/)

## micro:bit是什么？

<iframe src="//player.bilibili.com/player.html?aid=29828301&cid=51931009&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" width="800px" height="600px"> </iframe>
