## 1.4 小结 ##
----------

- 至此你已经完成了前期硬件软件的准备工作，打开MU，与PC连接好你的Micro:bit，下一章我们将正式开始MicroPython的学习。
- 本教材部分材料来自codewithmu官方网站：[https://codewith.mu/en/](https://codewith.mu/en/)
- 本教材部分材料来自micro:bit官方网站：[https://microbit.org/zh-CN/](https://microbit.org/zh-CN/)
- 本教材部分材料来自MicroPython官方网站：[http://microbit.org/zh-CN/guide/python/](http://microbit.org/zh-CN/guide/python/)

[![](https://i.imgur.com/RNOCi1W.png)](https://shop69086944.taobao.com/?spm=a230r.7195193.1997079397.2.S0soLy)

