## 3.5 课后练习 ##
----------


一、 编写一段程序，滚动显示你名字的首字母，延时500ms。效果如下：

![](https://i.imgur.com/zbIm1oA.gif)

二、 编写一段程序，显示一颗跳动的爱心。效果如下：

![](https://i.imgur.com/hURcHaA.gif)

