一、根据《小星星》简谱完成编码演奏。

![timg.jpg](http://www.lioncloud.top/index.php?user/publicLink&fid=bc30yaOTownCW2Sm6WezGgsrHBlQM7mWAiUoAMBgA3z2x5waStlaoeaXR_Moo2ie4r92XXsDuAhMqHhj58sMbe2T0-4yhHyxvQmSWdDs3BHxwEm14dk&file_name=/timg.jpg)


二、编码几首歌，用按键控制切换。上下首
